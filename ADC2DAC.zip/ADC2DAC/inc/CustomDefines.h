/*
 * CustomDefines.h
 *
 *  Created on: 20/08/2017
 *      Author: Fernandp
 */

#ifndef CUSTOMDEFINES_H_
#define CUSTOMDEFINES_H_

//#define ADC3_DR_ADDRESS     (uint32_t)(&(ADC3->DR))//((uint32_t)0x4001224C)
#define BUFFER_SIZE			1024
#define BAUDRATE			230400
typedef unsigned char bool;

#endif /* CUSTOMDEFINES_H_ */
